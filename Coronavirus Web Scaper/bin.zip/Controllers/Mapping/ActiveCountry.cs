﻿namespace Coronavirus_Web_Scaper.Controllers.Mapping
{
	public class ActiveCountry
	{
		public int Current { get; set; }

		public CurrentByType Current_by_type { get; set; }
	}
}
