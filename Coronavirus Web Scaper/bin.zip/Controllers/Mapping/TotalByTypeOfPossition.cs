﻿namespace Coronavirus_Web_Scaper.Controllers.Mapping
{
	public class TotalByTypeOfPossition
	{
		public int Doctor { get; set; }

		public int Nurces { get; set; }

		public int Paramedics_1 { get; set; }

		public int Paramedics_2 { get; set; }

		public int Other { get; set; }
	}
}
