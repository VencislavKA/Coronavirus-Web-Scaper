﻿namespace Coronavirus_Web_Scaper.Controllers.Mapping
{
	public class RecoveredCountry
	{
		public int Total { get; set; }

		public int Last { get; set; }
	}
}
