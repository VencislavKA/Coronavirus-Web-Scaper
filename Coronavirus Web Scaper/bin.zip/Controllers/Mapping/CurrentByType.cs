﻿namespace Coronavirus_Web_Scaper.Controllers.Mapping
{
	public class CurrentByType
	{
		public int Hospitalized { get; set; }

		public int Icu { get; set; }
	}
}
