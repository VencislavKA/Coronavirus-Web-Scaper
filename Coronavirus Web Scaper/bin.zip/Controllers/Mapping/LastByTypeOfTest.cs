﻿namespace Coronavirus_Web_Scaper.Controllers.Mapping
{
	public class LastByTypeOfTest
	{
		public int Pcr { get; set; }

		public int Antigen { get; set; }
	}
}
