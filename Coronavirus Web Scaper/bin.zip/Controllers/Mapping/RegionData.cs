﻿namespace Coronavirus_Web_Scaper.Controllers.Mapping
{
	public class RegionData
	{
		public ConfirmedRegion Confirmed { get; set; }

		public VaccinatedRegion Vaccinated { get; set; }
	}
}
