﻿namespace Coronavirus_Web_Scaper.Controllers.Mapping
{
	public class LastByTypeOfVaccine
	{
		public int Pfeizer { get; set; }

		public int Astrazeneca { get; set; }

		public int Moderna { get; set; }

		public int Janssen { get; set; }
	}
}
