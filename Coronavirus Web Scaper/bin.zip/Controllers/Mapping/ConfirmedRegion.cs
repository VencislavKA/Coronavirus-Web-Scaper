﻿namespace Coronavirus_Web_Scaper.Controllers.Mapping
{
	public class ConfirmedRegion
	{
		public int Total { get; set; }

		public int Last { get; set; }
	}
}
