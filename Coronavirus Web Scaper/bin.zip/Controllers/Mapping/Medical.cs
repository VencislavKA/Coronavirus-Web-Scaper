﻿namespace Coronavirus_Web_Scaper.Controllers.Mapping
{
	public class Medical
	{
		public int Total { get; set; }

		public TotalByTypeOfPossition Total_by_type { get; set; }

		public int Last { get; set; }

		public LastByTypeOfPossition Last_by_type { get; set; }
	}
}
