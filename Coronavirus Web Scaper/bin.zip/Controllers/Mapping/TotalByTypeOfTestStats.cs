﻿namespace Coronavirus_Web_Scaper.Controllers.Mapping
{
	public class TotalByTypeOfTestStats
	{
		public double Pcr { get; set; }

		public double Antigen { get; set; }
	}
}
