﻿namespace Coronavirus_Web_Scaper.Controllers.Mapping
{
	public class TestedStats
	{
		public TotalByTypeOfTestStats Total_by_type_prc { get; set; }

		public LastByTypeOfTestStats Last_by_type_prc { get; set; }
	}
}
