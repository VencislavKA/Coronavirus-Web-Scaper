﻿namespace Coronavirus_Web_Scaper.Controllers.Mapping
{
	public class Region
	{
		public string NameByЕКАТТЕ { get; set; }

		public string Name { get; set; }

		public RegionData RegisonData { get; set; }
	}
}
