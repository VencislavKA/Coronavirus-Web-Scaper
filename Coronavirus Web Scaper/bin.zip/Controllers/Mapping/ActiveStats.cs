﻿namespace Coronavirus_Web_Scaper.Controllers.Mapping
{
	public class ActiveStats
	{
		public double Hospitalized_per_active { get; set; }

		public double Icu_per_hospitalized { get; set; }
	}
}
